package com.example.minhas_metas_vinicius

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class tela_frequencia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.com_que_frequencia)
        val voltar4 : ImageView =findViewById(R.id.imageVoltar5)
        voltar4.setOnClickListener {
            finish()
        }
        val umaVez : TextView =findViewById(R.id.umavez)
        umaVez.setOnClickListener {
            abrirPorQuantoTempo(umaVez.text.toString())

        }
        val tresVez : TextView =findViewById(R.id.tresvez)
        tresVez.setOnClickListener {
            abrirPorQuantoTempo(tresVez.text.toString())

        }
        val cincoVez : TextView =findViewById(R.id.cincovez)
        cincoVez.setOnClickListener {
            abrirPorQuantoTempo(cincoVez.text.toString())

        }
        val todoDia : TextView =findViewById(R.id.todosdias)
        todoDia.setOnClickListener {
            abrirPorQuantoTempo(todoDia.text.toString())

        }

    }

    fun abrirPorQuantoTempo(tempoEscolhido2 : String ){
        val exercicio = intent.getStringExtra("habilidade")
        startActivity(
            Intent(this,tela_tempo::class.java).putExtra("tempo",tempoEscolhido2).putExtra("exercicio",exercicio)
        )
    }
}