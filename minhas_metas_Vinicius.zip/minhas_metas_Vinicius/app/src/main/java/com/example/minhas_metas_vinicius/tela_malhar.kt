package com.example.minhas_metas_vinicius

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class tela_malhar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela_malhar)

        val horario= intent.getStringExtra("horario")
        val tempo= intent.getStringExtra("tempo")
        val exercicio=intent.getStringExtra("exercicio")
        val habilidade=intent.getStringExtra("habilidade")

        val voltar7: ImageView = findViewById(R.id.imageView8)

        val melhorhorario: TextView = findViewById(R.id.textView37)
        val tempomanha: TextView = findViewById(R.id.textView38)

        melhorhorario.text = horario
        tempomanha.text = tempo

        voltar7.setOnClickListener {
            finish()
        }
    }
}