package com.example.minhas_metas_vinicius

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class tela_exercicio : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_exercicio)
//        val voltar : ImageView=findViewById(R.id.imageViewVoltar)
//        voltar.setOnClickListener {
//            finish()
//        }
        val malhar : TextView=findViewById(R.id.malhar1)
        malhar.setOnClickListener {
        abrirTelaComQueFrequencia("malhar")

        }
        val correr : TextView=findViewById(R.id.correr1)
        correr.setOnClickListener {
            abrirTelaComQueFrequencia("correr")

        }
        val caminhar : TextView=findViewById(R.id.caminhar1)
        caminhar.setOnClickListener {
            abrirTelaComQueFrequencia("caminhar")

        }
        val fazerYoga : TextView=findViewById(R.id.fazeryoga1)
        fazerYoga.setOnClickListener {
            abrirTelaComQueFrequencia("fazerYoga")

        }

    }

    fun abrirTelaComQueFrequencia(exercicioEscolhido : String ){
        startActivity(
            Intent(this,tela_frequencia::class.java).putExtra("habilidade",exercicioEscolhido)
        )
    }

}