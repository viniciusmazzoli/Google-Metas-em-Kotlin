package com.example.minhas_metas_vinicius

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class tela_tempo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.por_quanto_tempo)
        val voltar4 : ImageView =findViewById(R.id.imageVoltar4)
        voltar4.setOnClickListener {
            finish()
        }
        val quinzeMin : TextView =findViewById(R.id.quinzemin)
        quinzeMin.setOnClickListener {
            abrirTelaMelhorHorario(quinzeMin.text.toString())

        }
        val trintaMin : TextView =findViewById(R.id.trintamin)
        trintaMin.setOnClickListener {
            abrirTelaMelhorHorario(trintaMin.text.toString())

        }
        val umahora : TextView =findViewById(R.id.umahora)
        umahora.setOnClickListener {
            abrirTelaMelhorHorario(umahora.text.toString())

        }
        val duashora : TextView =findViewById(R.id.duashora)
        duashora.setOnClickListener {
            abrirTelaMelhorHorario(duashora.text.toString())

        }
    }
    fun abrirTelaMelhorHorario(melhorhorario2 : String ){
        val tempo= intent.getStringExtra("tempo")
        val exercicio= intent.getStringExtra("exercicio")
        startActivity(
            Intent(this,melhor_horario::class.java).putExtra("horario",melhorhorario2).putExtra("tempo",tempo).putExtra("exercicio",exercicio)
        )
    }
}