package com.example.minhas_metas_vinicius

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class tela_aprender : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_aprender)
        val voltar2 : ImageView =findViewById(R.id.imageVoltar2)
        voltar2.setOnClickListener {
            finish()
        }
        val aprender : TextView =findViewById(R.id.aprender1)
        aprender.setOnClickListener {
            abrirTelaComQueFrequencia("aprender")

        }
        val aprenderProgamacao : TextView =findViewById(R.id.aprenderprogamacao2)
        aprenderProgamacao.setOnClickListener {
            abrirTelaComQueFrequencia("aprenderProgamacao")

        }
        val praticarInstrumento : TextView =findViewById(R.id.praticar3)
        praticarInstrumento.setOnClickListener {
            abrirTelaComQueFrequencia("praticarInstrumento")

        }
        val fazerArte : TextView =findViewById(R.id.fazer4)
        fazerArte.setOnClickListener {
            abrirTelaComQueFrequencia("fazerArte")

        }

    }
    fun abrirTelaComQueFrequencia(habilidadeEscolhido2 : String ){
        startActivity(
            Intent(this,tela_frequencia::class.java).putExtra("habilidade2",habilidadeEscolhido2)
        )
    }
}