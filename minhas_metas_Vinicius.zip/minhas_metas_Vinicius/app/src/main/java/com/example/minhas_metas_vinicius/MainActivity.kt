package com.example.minhas_metas_vinicius

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val constraintLayoutExercicio: ConstraintLayout = findViewById(R.id.constraintLayoutExercicio)
        constraintLayoutExercicio.setOnClickListener{
            abrirTelaExercicio()
        }
        val constraintLayoutAprender: ConstraintLayout = findViewById(R.id.constraintLayoutAprender)
        constraintLayoutAprender.setOnClickListener{
            abrirTelaAprender()
        }

    }
    fun abrirTelaExercicio(){
        startActivity(Intent(this,tela_exercicio::class.java))
    }
    fun abrirTelaAprender(){
        startActivity(Intent(this,tela_aprender::class.java))
    }
}