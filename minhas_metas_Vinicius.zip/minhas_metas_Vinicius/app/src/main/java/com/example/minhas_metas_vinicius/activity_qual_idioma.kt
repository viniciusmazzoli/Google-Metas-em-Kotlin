package com.example.minhas_metas_vinicius

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class activity_qual_idioma : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.qual_idioma)
        val voltar3 : ImageView =findViewById(R.id.imageVoltar3)
        voltar3.setOnClickListener {
            finish()
        }
    }
}